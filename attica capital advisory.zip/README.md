
  # attica capital advisory

  This is a code bundle for attica capital advisory. The original project is available at https://www.figma.com/design/YlHpiVvCXUNx88hkEPX5OJ/attica-capital-advisory.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  